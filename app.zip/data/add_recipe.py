from flask_wtf import FlaskForm
from wtforms import SubmitField, StringField, FileField, TextAreaField
from wtforms.validators import DataRequired


class AddRecipeForm(FlaskForm):
    title = StringField('Recipe title', validators=[DataRequired()])
    ingredients = TextAreaField('Ingredients', validators=[DataRequired()])
    steps = TextAreaField('Steps', validators=[DataRequired()])
    photo = FileField('Photo', validators=[DataRequired()])
    about = TextAreaField('About')
    submit = SubmitField('Создать рецепт')
