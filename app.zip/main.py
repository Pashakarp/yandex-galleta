from flask import Flask, render_template, redirect, request
from flask_login import LoginManager, login_user, logout_user, login_required, current_user
from data.register import RegisterForm
from data import db_session
import os
from data.add_recipe import AddRecipeForm
from data.login import LoginForm
from data.users import User
from data.recipe import Recipe

app = Flask(__name__)
app.config['SECRET_KEY'] = 'yandexlyceum_secret_key'
app.config["IMAGE_UPLOADS"] = "static/img/uploads/"
app.config["ALLOWED_IMAGE_EXTENSIONS"] = ["PNG", "JPG", "JPEG"]
login_manager = LoginManager()
login_manager.init_app(app)


def allowed_image(filename):
    if '.' not in filename:
        return False
    ext = filename.split('.')[1]
    if ext.upper() in app.config["ALLOWED_IMAGE_EXTENSIONS"]:
        return True
    else:
        return False


def main():
    db_session.global_init("db/galleta.sqlite")

    @app.route('/')
    @app.route('/index')
    def index():
        return render_template('index.html')

    @app.route('/home')
    def home():
        session = db_session.create_session()
        recipes = session.query(Recipe).all()
        return render_template('home.html', recipes=recipes, title='Домашняя страница')

    @app.route('/register', methods=['GET', 'POST'])
    def registration():
        form = RegisterForm()
        if form.validate_on_submit():
            if form.password.data != form.password_again.data:
                return render_template('register.html', title='Регистрация',
                                       form=form,
                                       message="Пароли не совпадают")
            session = db_session.create_session()
            if session.query(User).filter(User.email == form.email.data).first():
                return render_template('register.html', title='Регистрация',
                                       form=form,
                                       message="Такой пользователь уже есть")
            user = User(
                surname=form.surname.data,
                name=form.name.data,
                age=form.age.data,
                email=form.email.data
            )
            user.set_password(form.password.data)
            session.add(user)
            session.commit()
            return redirect('/login')
        return render_template('register.html', title='Регистрация', form=form)

    @app.route('/login', methods=['GET', 'POST'])
    def login():
        form = LoginForm()
        if form.validate_on_submit():
            session = db_session.create_session()
            user = session.query(User).filter(User.email == form.email.data).first()
            if user and user.check_password(form.password.data):
                login_user(user)
                return redirect("/home")
            return render_template('login.html',
                                   form=form)
        return render_template('login.html', form=form)

    @app.route('/logout')
    @login_required
    def logout():
        logout_user()
        return redirect("/")

    @login_manager.user_loader
    def load_user(user_id):
        session = db_session.create_session()
        return session.query(User).get(user_id)

    @app.route('/add_recipe', methods=['GET', 'POST'])
    def add_recipe():
        form = AddRecipeForm()
        if form.validate_on_submit():
            session = db_session.create_session()
            if session.query(Recipe).filter(Recipe.title == form.title.data).first():
                return render_template('add_recipe.html', title='Добавление рецепта',
                                       form=form, message='Такой рецепт уже есть')

            image = request.files["photo"]

            # Проверка того, что у картинки есть имя
            if image.filename == '':
                return render_template('add_recipe.html', title='Добавление рецепта',
                                       form=form, message='У картинки нет имени')

            # Проверка формата картинки
            if not allowed_image(image.filename):
                return render_template('add_recipe.html', title='Добавление рецепта',
                                       form=form, message='Доступные форматы файлов: PNG, JPG, JPEG')

            # Сохранение картинки в определенную директорию
            image.save(os.path.join(app.config["IMAGE_UPLOADS"], image.filename))
            print(f'Картинка сохранена сюда: {os.path.join(app.config["IMAGE_UPLOADS"], image.filename)}')

            recipe = Recipe(
                title=form.title.data,
                ingredients=form.ingredients.data,
                steps=form.steps.data,
                photo=os.path.join(app.config["IMAGE_UPLOADS"], image.filename),
                about=form.about.data,
                user_id=current_user.id
            )
            session.add(recipe)
            session.commit()
            return redirect('/home')
        return render_template('add_recipe.html', title='Добавление рецепта', form=form)

    app.run(port=8080, host='127.0.0.1')


if __name__ == '__main__':
    main()
